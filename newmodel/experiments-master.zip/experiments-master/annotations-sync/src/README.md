# Annotations synchronization

This experiment shows how to display additional content in sync with annotations.

# Build

* `npm install`
* `gulp`
