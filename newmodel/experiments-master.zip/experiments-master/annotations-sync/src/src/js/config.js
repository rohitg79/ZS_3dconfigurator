var config = {
    URLID: 'd6f31e3957a144a2ab23871a26373a2a'
};

module.exports = config;
