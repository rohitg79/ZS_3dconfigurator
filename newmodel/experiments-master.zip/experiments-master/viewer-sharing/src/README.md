# Viewer sharing

This experiment shows how 2 or more people can view a 3D with the same
point of view, across multiple browsers.

## Build

* `npm install`
* `gulp`
