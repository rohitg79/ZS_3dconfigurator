var config = {
    URLID: 'aca5b8c72b324b30827bf327e942a438',
    OPTION_PREFIXES: [
        'options_',
    ],
    OPTION_DEFAULTS: [
        'options_metallic',
    ],
    OPTION_ORDER: [
        'options_metallic',
        'options_leather',
    ]
};

module.exports = config;
