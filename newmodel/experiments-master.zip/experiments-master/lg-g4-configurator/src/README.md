# Watch Configurator

This app lets you try different options for a watch

## Build

* `npm install`
* `gulp`

## Configure the Configurator

In `src/js/config.js`
* Edit the urlid with the urlid of the model to be displayed
* Edit the prefix used to detect meshes used as options
